package cn.code.testsys.qo;

public class CourseQueryObject extends QueryObject{
}
